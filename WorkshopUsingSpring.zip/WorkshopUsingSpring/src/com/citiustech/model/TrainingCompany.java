package com.citiustech.model;

public interface TrainingCompany {
	public void conductTraining();

}
