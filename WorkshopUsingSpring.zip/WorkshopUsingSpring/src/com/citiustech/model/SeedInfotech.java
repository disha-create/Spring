package com.citiustech.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SeedInfotech implements TrainingCompany {

	@Autowired
	private Trainer trainer;
	
	
	public SeedInfotech() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SeedInfotech(Trainer trainer) {
		System.out.println("SeedInfoTech company conducting training");
		this.trainer = trainer;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	@Override
	public String toString() {
		return "SeedInfotech [trainer=" + trainer + "]";
	}

	@Override
	public void conductTraining(){
		System.out.println("SeedInfotech::conductTraining()");
		trainer.train();
	}

}
