package com.citiustech.model;

public interface Trainer {

	public void train();
}
