package com.citiustech.model;

import java.util.List;

public class JavaTrainer implements Trainer {

	
	private String name;
	private List<String> subjects;
	
	public JavaTrainer() {
		System.out.println("Pramaeterless constructor for javaTrainer");
	}
	
	public JavaTrainer(String name, List<String> subjects) {
	
		System.out.println("Pramaeterized constructor for javaTrainer");
		this.name = name;
		this.subjects = subjects;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}

	@Override
	public String toString() {
		return "JavaTrainer [name=" + name + ", subjects=" + subjects + "]";
	}
	
	public void train(){
		System.out.println("Java training...");
		System.out.printf("%s is teacing %s",name,subjects);
	}
	
}
