package com.citiustech.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.citiustech.model.JavaTrainer;
import com.citiustech.model.Trainer;

@Configuration //<beans>
@ComponentScan(basePackages = "com.citiustech.*") //<context:component-scan>
@PropertySource("classpath:app.properties")
public abstract class TrainingConfiguration {
	
	
	@Value("${jt1.name}")
	private String jt1Name;
	
	
	@Value("#{${jt1.subjects}}")
	private List<String> jt1Subjects;
	
	/*
	 * THIS IS FOR PROVIDING LIST OR COLLLECTION DATA TYPE TO THE OBJECT....
	 * <bean id="javaTrainer" class="com.citiustech.model.JavaTrainer"> <property
	 * name="name" value="Ajay" /> <property name="subjects"> <list>
	 * <value>OOP</value> <value>Reflection</value> <value>Collection</value>
	 * </list> </property> </bean>
	 */

	 
	@Bean //<bean id="javaTrainer" class="...">
	public Trainer javaTrainer() {
		/*
		 * List<String> subjects = new ArrayList<String>(); subjects.add("OOP");
		 * subjects.add("Reflection"); subjects.add("Collection");
		 */
		
		JavaTrainer trainer = new JavaTrainer();
		//trainer.setName("Ajay");
		//trainer.setSubjects(subjects);
		
		
		trainer.setName(jt1Name);
		trainer.setSubjects(jt1Subjects);
		
		return trainer;
	}

}
