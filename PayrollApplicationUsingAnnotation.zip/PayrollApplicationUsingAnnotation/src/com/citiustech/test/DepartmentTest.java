package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.model.Department;

public class DepartmentTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("payroll.xml");
		
		Department dept = context.getBean("sales",Department.class);
		System.out.println(dept);
		
	}

}
