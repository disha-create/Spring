package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.citiustech.config.TestingConfiguration;
import com.citiustech.model.Department;
import com.citiustech.model.Employee;

public class DepartmentEmployeeTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(TestingConfiguration.class);
	
		Department department = context.getBean("sales",Department.class);
		System.out.println(department);
//		System.out.println(department.getTotalIncome());
		
		Employee emp = context.getBean("Disha",Employee.class);
		System.out.println(emp);
		
		Employee emp1 = context.getBean("Manjiri",Employee.class);
		System.out.println(emp1);
		
		Employee emp2 = context.getBean("Pramod",Employee.class);
		System.out.println(emp2);
	}

}
