package com.citiustech.model;

import java.util.Date;

public class Employee {
	
	private int id;
	private int hours;
	private float rate;
	private String name;
	private Date hireDate;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless constructor for employee");
	}


	public Employee(int id, int hours, float rate, String name, Date hireDate) {
		super();
		System.out.println("Parameterized constructor for employee");
		this.id = id;
		this.hours = hours;
		this.rate = rate;
		this.name = name;
		this.hireDate = hireDate;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getHours() {
		return hours;
	}


	public void setHours(int hours) {
		this.hours = hours;
	}


	public float getRate() {
		return rate;
	}


	public void setRate(float rate) {
		this.rate = rate;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getHireDate() {
		return hireDate;
	}


	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}


	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", hours=" + hours + ", rate=" + rate + ", name=" + name + ", hireDate="
				+ hireDate + ", getId()=" + getId() + ", getHours()=" + getHours() + ", getRate()=" + getRate()
				+ ", getName()=" + getName() + ", getHireDate()=" + getHireDate() + ", getNetIncome()=" + getNetIncome()
				+ "]";
	}


	public double getNetIncome(){
		return rate*hours;
	}

}
