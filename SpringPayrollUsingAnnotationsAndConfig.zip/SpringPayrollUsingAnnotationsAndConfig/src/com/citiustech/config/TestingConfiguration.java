package com.citiustech.config;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.citiustech.model.Department;
import com.citiustech.model.Employee;

@Component
@ComponentScan(basePackages = "com.citiustech.*")
@PropertySource("classpath:app.properties")
public class TestingConfiguration {
	@Value("${emp1.id}")
	private int empId1;
	
	@Value("${emp1.hours}")
	private int empHours1;
	
	@Value("${emp1.rate}")
	private float empRate1;
	
	@Value("${emp1.name}")
	private String empName1;
	
	@Value("{dept1.name}")
	private String name;
	
	@Value("{dept1.location}")
	private String location;
	
	@Bean
	public Employee Disha(){
		Employee emp = new Employee();
		emp.setId(empId1);
		emp.setHours(empHours1);
		emp.setRate(empRate1);
		emp.setName(empName1);
		
		return emp;
	}

	@Bean
	public Department sales(){
		
		Department dt = new Department();
		dt.setName(name);
		dt.setLocation(location);
		
		return dt;
	}
	//Employee 2
	
	@Value("${emp2.id}")
	private int empId2;
	
	@Value("${emp2.hours}")
	private int empHours2;
	
	@Value("${emp2.rate}")
	private float empRate2;
	
	@Value("${emp2.name}")
	private String empName2;
	
	@Bean
	public Employee Manjiri(){
		Employee e1 = new Employee();
		e1.setId(empId2);
		e1.setHours(empHours2);
		e1.setRate(empRate2);
		e1.setName(empName2);
		
		return e1;
	}
	
	//Employee 3
	@Value("${emp3.id}")
	private int empId3;
	
	@Value("${emp3.hours}")
	private int empHours3;
	
	@Value("${emp3.rate}")
	private float empRate3;
	
	@Value("${emp3.name}")
	private String empName3;
	
	
	@Bean
	public Employee Pramod(){
		Employee e = new Employee();
		e.setId(empId3);
		e.setHours(empHours3);
		e.setRate(empRate3);
		e.setName(empName3);
		
		
		return e;
	}
}
