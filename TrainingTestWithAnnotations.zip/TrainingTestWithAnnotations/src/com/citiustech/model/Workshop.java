package com.citiustech.model;

public interface Workshop {

	void conductWorkshop();
}
