package com.citiustech.model;

public interface Trainer {
	void train();
}
