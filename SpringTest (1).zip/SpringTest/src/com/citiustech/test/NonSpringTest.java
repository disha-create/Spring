package com.citiustech.test;

import com.citiustech.payroll.Employee;

public class NonSpringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee jack = new Employee(1001, "Jack", "SE", 175000);
		System.out.printf("Jack's annual income = %.2f%n", jack.getAnnualIncome());
		
		Employee jill = new Employee(1002, "Jill", "SSE", 220000);
		System.out.printf("Jill's annual income = %.2f%n", jill.getAnnualIncome());

	}
}
