package com.citiustech.test;
import com.citiustech.model.Employee;
import org.spring
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//


public class SpringTestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("payroll.xml");
		Employee jack = context.getBean("jack", Employee.class);
		System.out.println(jack.getAnnualIncome());
	}

}


