package com.citiustech.model;

/**
 * @author DishaM2
 *
 */
public class Student {
	
	private int studentId;
	private String studentName;
	private String mobileNo;
	private String email;
	
	private Course course;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Student(int studentId, String studentName, String mobileNo, String email, Course course) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.mobileNo = mobileNo;
		this.email = email;
		this.course = course;
	}



	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	
	

	public Course getCourse() {
		return course;
	}


	public void setCourse(Course course) {
		this.course = course;
	}



	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", mobileNo=" + mobileNo
				+ ", email=" + email + ", course=" + course + "]";
	}


	
	
	
	

}
