package com.citiustech.model;

public class Course {
	
	private int CourseId;
	private String CourseName;
	private double fees;
	
	
	
	public Course() {
		this(0," ",0);
		// TODO Auto-generated constructor stub
	}

	public Course(int courseId, String courseName, double fees) {
		super();
		CourseId = courseId;
		CourseName = courseName;
		this.fees = fees;
	}
	
	public int getCourseId() {
		return CourseId;
	}
	public void setCourseId(int courseId) {
		CourseId = courseId;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}

	@Override
	public String toString() {
		return "Course [CourseId=" + CourseId + ", CourseName=" + CourseName + ", fees=" + fees + "]";
	}
	
	
	
	

}
