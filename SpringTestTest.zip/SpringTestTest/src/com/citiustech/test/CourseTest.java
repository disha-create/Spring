package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.model.Course;
import com.citiustech.model.Employee;
import com.citiustech.model.Student;

public class CourseTest {

	public static void main(String[] args) {
		
	
		ApplicationContext context = new ClassPathXmlApplicationContext("payroll.xml");
		System.out.println("******************* Container Loaded **************************");
		
//		Employee emp = context.getBean("jack", Employee.class);
//		System.out.println(emp);
		
		Course cour = context.getBean("course1",Course.class);
		System.out.println(cour);

		Student student = context.getBean("Student1",Student.class);
		System.out.println(student);
		
	}
	
}
