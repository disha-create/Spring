package com.citiustech.model;

import org.springframework.stereotype.Component;

@Component
public class Employee {
	
	private int Id;
	private int hours;
	private float rate;
	private String name;
	private String hiredate;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Prameterless constructor for employee");
	}

	public Employee(int id, int hours, float rate, String name, String hiredate) {
		super();
		System.out.println("Prameterized constructor for employee");
		Id = id;
		this.hours = hours;
		this.rate = rate;
		this.name = name;
		this.hiredate = hiredate;
	}

	public int getId() {
		return Id;
	}
	
	public void setId(int id) {
		Id = id;
	}
	
	public int getHours() {
		return hours;
	}
	
	public void setHours(int hours) {
		this.hours = hours;
	}
	
	public float getRate() {
		return rate;
	}
	
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getHiredate() {
		return hiredate;
	}
	
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	
	
	public float getNetIncome(){
		return hours*rate;
	}

	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", hours=" + hours + ", rate=" + rate + ", name=" + name + ", hiredate="
				+ hiredate + ", getId()=" + getId() + ", getHours()=" + getHours() + ", getRate()=" + getRate()
				+ ", getName()=" + getName() + ", getHiredate()=" + getHiredate() + ", getNetIncome()=" + getNetIncome()
				+ "]";
	}
	
	


}
