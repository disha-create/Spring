package com.citiustech.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Department {
	
	private int id;
	private String name;
	private String location;
	
	private List<Employee> employees;
	
	public Department() {
		// TODO Auto-generated constructor stub
		System.out.println("Prameterless constructor for department");
	}

	public Department(int id, String name, String location, List<Employee> employees) {
		super();
		System.out.println("Prameterized constructor for department");
		this.id = id;
		this.name = name;
		this.location = location;
		this.employees = employees;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public List<Employee> getEmployees() {
		return employees;
	}
	
	@Autowired
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
	
	public double getTotalIncome(){
		double totalIncome = 0;
		for (Employee emp : employees) {
			totalIncome = totalIncome + emp.getNetIncome();
			
		}
		return totalIncome;
		
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + ", location=" + location + ", employees=" + employees
				+ ", getId()=" + getId() + ", getName()=" + getName() + ", getLocation()=" + getLocation()
				+ ", getEmployees()=" + getEmployees() + ", getTotalIncome()=" + getTotalIncome() + "]";
	}
	
	

}
