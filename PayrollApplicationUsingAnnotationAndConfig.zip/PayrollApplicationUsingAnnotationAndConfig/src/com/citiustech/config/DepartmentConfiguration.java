package com.citiustech.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.citiustech.model.Department;
import com.citiustech.model.Employee;

@Component
@ComponentScan(basePackages="com.citiustech.*")
@PropertySource("classpath:app.properties")
public abstract class DepartmentConfiguration {
	//Employee1
	@Value("${emp1.id}")
	private int Id;
	
	@Value("${emp1.hours}")
	private int hours;
	
	@Value("${emp1.rate}")
	private float rate;
	
	@Value("${emp1.name}")
	private String name;
	
	@Value("${emp1.hierdate}")
	private String hiredate;
	
	//Employee2
	@Value("${emp2.id}")
	private int Id2;
	
	@Value("${emp2.hours}")
	private int hours2;
	
	@Value("${emp2.rate}")
	private float rate2;
	
	@Value("${emp2.name}")
	private String name2;
	
	@Value("${emp2.hierdate}")
	private String hiredate2;
		
		
	//Employee3
	@Value("${emp3.id}")
	private int Id3;
	
	@Value("${emp3.hours}")
	private int hours3;
	
	@Value("${emp3.rate}")
	private float rate3;
	
	@Value("${emp3.name}")
	private String name3;
	
	@Value("${emp3.hierdate}")
	private String hiredate3;	
	
	@Value("${dt.name}")
	private String dName;
	
	@Value("${dt.location}")
	private String dLocation;
	
	
	@Bean //<bean id="javaTrainer" class="...">
	public Employee Disha(){

		Employee employee = new Employee();
		employee.setHours(Id);
		employee.setName(name);
		employee.setRate(rate);
		return employee;
	}
	
	@Bean //<bean id="javaTrainer" class="...">
	public Employee Manjiri(){

		Employee employee2 = new Employee();
		employee2.setHours(Id2);
		employee2.setName(name2);
		employee2.setRate(rate2);
		return employee2;
	}
	
	@Bean //<bean id="javaTrainer" class="...">
	public Employee Pramod(){

		Employee employee3 = new Employee();
		employee3.setHours(Id3);
		employee3.setName(name3);
		employee3.setRate(rate3);
		return employee3;
	}
	
	
	@Bean
	public Department sales(){
		Department dept = new Department();
		
		dept.setName(dName);
		dept.setLocation(dLocation);
		
		return dept;
	}
}
	
