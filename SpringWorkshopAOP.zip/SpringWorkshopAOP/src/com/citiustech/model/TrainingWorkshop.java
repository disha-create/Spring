package com.citiustech.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TrainingWorkshop implements Workshop {
	
	
	private TrainingCompany trainingCompany;
		
	public TrainingWorkshop() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("ParameterLess constructor for TrainingWorkshop");
	}

	@Autowired
	public TrainingWorkshop(TrainingCompany trainingCompany) {
		super();
		System.out.println("Parameterized constructor for TrainingWorkshop");
		this.trainingCompany = trainingCompany;
	}

	public TrainingCompany getTrainingCompany() {
		return trainingCompany;
	}

	public void setTrainingCompany(TrainingCompany trainingCompany) {
		this.trainingCompany = trainingCompany;
	}

	@Override
	public String toString() {
		return "TrainingWorkshop [trainingCompany=" + trainingCompany + ", getTrainingCompany()=" + getTrainingCompany()
				+ "]";
	}

	public void conductWorkshop(){
		System.out.println("TrainingWorkshop::conductTraining()");
		trainingCompany.conductTraining();
	}

}
