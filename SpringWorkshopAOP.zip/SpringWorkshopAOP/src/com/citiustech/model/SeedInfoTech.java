package com.citiustech.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SeedInfoTech implements TrainingCompany {
	
	@Autowired
	private List<Trainer> trainer;
	
	public SeedInfoTech() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless constructor for SeefInfoTech");
	}

	
	
	public SeedInfoTech(List<Trainer> trainer) {
		super();
		this.trainer = trainer;
	}



	public List<Trainer> getTrainer() {
		return trainer;
	}



	public void setTrainer(List<Trainer> trainer) {
		this.trainer = trainer;
	}


	@Override
	public String toString() {
		return "SeedInfoTech [trainer=" + trainer + ", getTrainer()=" + getTrainer() + "]";
	}



	@Override
	public void conductTraining(){
		System.out.println("TrainingCompany::conductTraining()");
		
		for (Trainer trainer : trainer) {
			trainer.train();
			
		}
	}



}
