package com.citiustech.model;

import java.util.List;

import org.springframework.stereotype.Component;

public class JavaTrainer implements Trainer {
	
	private String name;
	private List<String> subjects;
	
	
	
	public JavaTrainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JavaTrainer(String name, List<String> subjects) {
		super();
		this.name = name;
		this.subjects = subjects;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getSubjects() {
		return subjects;
	}

	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}

	
	@Override
	public String toString() {
		return "JavaTrainer [name=" + name + ", subjects=" + subjects + ", getName()=" + getName() + ", getSubjects()="
				+ getSubjects() + "]";
	}

	@Override
	public void train(){
		System.out.println("JavaTrainer::train()");
		
	}

}
