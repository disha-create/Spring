package com.citiustech.AOP;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@Aspect
@EnableAspectJAutoProxy
public class Participants {
	
	@Pointcut("execution(* *.train(..))")
	public void training() {}
	
	@Before("training()")
	public void beforeTraininf(){
		System.out.println("Participants must take their seats");
		System.out.println("Participants must switch off their phones");
		
	}
	
	@After("training()")
    public void afterTraininf(){
		System.out.println("Training was completed successfully");
	}

}
