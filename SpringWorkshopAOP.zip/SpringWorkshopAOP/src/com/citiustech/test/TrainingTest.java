package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.citiustech.config.TrainingConfiguration;
import com.citiustech.model.TrainingWorkshop;
import com.citiustech.model.Workshop;

public class TrainingTest {
	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(TrainingConfiguration.class);
		
		Workshop workshop = context.getBean("trainingWorkshop", TrainingWorkshop.class);
		workshop.conductWorkshop();
		
	}

}
