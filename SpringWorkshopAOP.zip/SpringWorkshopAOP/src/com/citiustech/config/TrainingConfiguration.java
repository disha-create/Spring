package com.citiustech.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;


import com.citiustech.model.Trainer;
import com.citiustech.model.JavaTrainer;
import com.citiustech.model.DotNetTrainer;;

@Configuration
@ComponentScan(basePackages="com.citiustech.*")
@PropertySource("classpath:app.properties")
public class TrainingConfiguration {
	
	@Value("${jt1.name}")
	private String jt1Name;
	
	@Value("#{${jt1.subjects}}")
	private List<String> jt1Subjects;
	
	@Value("${dt1.name}")
	private String dt1Name;
	
	@Value("#{${dt1.subjects}}")
	private List<String> dt1Subjects;
	
	@Bean
	public Trainer JavaTrainer(){
		 JavaTrainer jt = new JavaTrainer();
		 jt.setName(jt1Name);
		 jt.setSubjects(jt1Subjects);
		 
		 return jt;
	}
	
	@Bean
	public Trainer DotNetTrainer(){
		DotNetTrainer dt = new DotNetTrainer();
		dt.setName(dt1Name);
		dt.setSubjects(dt1Subjects);
		return dt;
	}

}
