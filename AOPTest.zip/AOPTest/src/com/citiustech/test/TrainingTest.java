package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.config.TrainingConfiguration;
import com.citiustech.model.JavaTrainer;
import com.citiustech.model.Trainer;
import com.citiustech.model.TrainingWorkshop;
import com.citiustech.model.Workshop;

public class TrainingTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ApplicationContext context = new ClassPathXmlApplicationContext("training.xml");
		ApplicationContext context = new AnnotationConfigApplicationContext(TrainingConfiguration.class);
		
		/*
		 * Trainer trainer = context.getBean("javaTrainer", JavaTrainer.class);
		 * trainer.train();
		 */
		 
		Workshop workshop = context.getBean("trainingWorkshop", TrainingWorkshop.class);
		workshop.conductWorkshop();
	}

}




