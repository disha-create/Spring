package com.citiustech.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.citiustech.model.DotNetTrainer;
import com.citiustech.model.JavaTrainer;
import com.citiustech.model.Trainer;

@Configuration //<beans>
@ComponentScan(basePackages = "com.citiustech.*") //<context:component-scan>
@PropertySource("classpath:app.properties")
public class TrainingConfiguration {

	@Value("${jt1.name}")
	private String jt1Name;
	
	@Value("#{${jt1.subjects}}")
	private List<String> jt1Subjects;
	
	@Value("${dt1.name}")
	private String dt1Name;
	
	@Value("#{${dt1.subjects}}")
	private List<String> dt1Subjects;

	@Bean
	public Trainer javaTrainer() {
		JavaTrainer trainer = new JavaTrainer();
		//trainer.setName("Ajay");
		trainer.setName(jt1Name);
		//trainer.setSubjects(subjects);
		trainer.setSubjects(jt1Subjects);
		
		return trainer;
	}
	
	
	@Bean 
	public Trainer dotnetTrainer() { 
		DotNetTrainer trainer = new DotNetTrainer(); 
	    trainer.setName(dt1Name); 
	    trainer.setSubjects(dt1Subjects);
	  
		return trainer; 
	}
}




