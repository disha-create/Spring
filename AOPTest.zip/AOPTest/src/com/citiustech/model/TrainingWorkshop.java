package com.citiustech.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TrainingWorkshop implements Workshop {
	
	private TrainingCompany trainingCompany;
	
	public TrainingWorkshop() {
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless ctor of TrainingWorkshop");
	}
	
	@Autowired
	public TrainingWorkshop(TrainingCompany trainingCompany) {
		super();
		this.trainingCompany = trainingCompany;
	}
	
	public TrainingCompany getTrainingCompany() {
		return trainingCompany;
	}

	public void setTrainingCompany(TrainingCompany trainingCompany) {
		this.trainingCompany = trainingCompany;
	}

	@Override
	public void conductWorkshop() {
		// TODO Auto-generated method stub
		System.out.println("TrainingWorkshop::conductWorkshop()");
		trainingCompany.conductTraining();
	}

}
