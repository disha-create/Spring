package com.citiustech.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class SeedInfotech implements TrainingCompany {
	
	/*
	 * @Autowired //@Qualifier("dotnetTrainer") private Trainer trainer;
	 * 
	 * public SeedInfotech() { // TODO Auto-generated constructor stub
	 * System.out.println("Parameterless ctor of SeedInfotech"); }
	 * 
	 * public SeedInfotech(Trainer trainer) { super(); this.trainer = trainer; }
	 * 
	 * public Trainer getTrainer() { return trainer; }
	 * 
	 * public void setTrainer(Trainer trainer) { this.trainer = trainer; }
	 * 
	 * @Override public void conductTraining() { // TODO Auto-generated method stub
	 * System.out.println("SeedInfotech::conductTraining()"); trainer.train(); }
	 */
	
	@Autowired
	private List<Trainer> trainer; 
	
	public SeedInfotech() {
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless ctor of SeedInfotech");
	}

	public SeedInfotech(List<Trainer> trainer) {
		super();
		this.trainer = trainer;
	}

	public List<Trainer> getTrainer() {
		return trainer;
	}

	public void setTrainer(List<Trainer> trainer) {
		this.trainer = trainer;
	}
	
	@Override 
	public void conductTraining() {
		System.out.println("SeedInfotech::conductTraining()");
		for (Trainer t : trainer) {
			t.train();
		}
	}
}





