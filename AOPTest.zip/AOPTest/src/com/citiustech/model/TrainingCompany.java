package com.citiustech.model;

public interface TrainingCompany {
	void conductTraining();
}
