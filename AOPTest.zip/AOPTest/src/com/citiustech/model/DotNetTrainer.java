package com.citiustech.model;

import java.util.List;

import org.springframework.context.annotation.Bean;

public class DotNetTrainer implements Trainer {
	
	private String name;
	private List<String> subjects;
	
	public DotNetTrainer() {
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless ctor of DotNetTrainer");
	}

	public DotNetTrainer(String name, List<String> subjects) {
		this.name = name;
		this.subjects = subjects;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getSubjects() {
		return subjects;
	}

	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}
	
	@Override
	public void train() {
		// TODO Auto-generated method stub
		System.out.println("DotNetTrainer::train()");
		System.out.printf("%s is training on %s%n", name, subjects);
	}

	@Override
	public String toString() {
		return "DotNetTrainer [name=" + name + ", subjects=" + subjects + "]";
	}
}
