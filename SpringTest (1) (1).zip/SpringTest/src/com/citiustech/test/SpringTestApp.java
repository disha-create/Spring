package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.payroll.Employee;

public class SpringTestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("payroll.xml");
		System.out.println("******************* Container Loaded **************************");
		//Employee emp = context.getBean(Employee.class);
		//Employee emp = (Employee) context.getBean("jack");
		Employee emp = context.getBean("jack", Employee.class);
		System.out.println(emp);
	}

}

	

