package com.citiustech.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.model.Trainer;
import com.citiustech.model.TrainingWorkshop;
import com.citiustech.model.Workshop;

public class TrainingTest {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("payroll.xml");
		
		Workshop workshop = context.getBean("trainingWorkshop",TrainingWorkshop.class);
		workshop.conductWorkshop();
		
//		Trainer trainer = context.getBean("trainer" , Trainer.class);
//		trainer.train();
		
	}

}
