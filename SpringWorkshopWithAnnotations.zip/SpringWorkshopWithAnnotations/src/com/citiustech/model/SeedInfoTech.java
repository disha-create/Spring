package com.citiustech.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SeedInfoTech implements TrainingCompany {

	
	private Trainer trainer;
	
	public SeedInfoTech() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Autowired
	public SeedInfoTech(Trainer trainer) {
		super();
		this.trainer = trainer;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	
	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	
	@Override
	public String toString() {
		return "SeedInfoTech [trainer=" + trainer + "]";
	}
	
	@Override
	public void conductTraining(){
		System.out.println("SeedInfotech company conducting tarining");
		System.out.println("SeedInfotech::conductTraining()");
		trainer.train();
	}

	
}
