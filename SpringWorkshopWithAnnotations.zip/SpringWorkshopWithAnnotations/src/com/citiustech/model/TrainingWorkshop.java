package com.citiustech.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TrainingWorkshop implements Workshop {

	
	private TrainingCompany trainingCompany;

	
	public TrainingWorkshop() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("TrainingWorkshop conducting training");
	}

	@Autowired
	public TrainingWorkshop(TrainingCompany trainingCompany) {
		super();
		this.trainingCompany = trainingCompany;
	}

	public TrainingCompany getTrainingCompany() {
		return trainingCompany;
	}

	public void setTrainingCompany(TrainingCompany trainingCompany) {
		this.trainingCompany = trainingCompany;
	}
	
	@Override
	public String toString() {
		return "TrainingWorkshop [trainingCompany=" + trainingCompany + "]";
	}

	@Override
	public void conductWorkshop() {
		System.out.println("TrainingWorkshop conducting workshop");
		System.out.println("TrainingWorkshop::conductTrainig");
		trainingCompany.conductTraining();
	}

}
