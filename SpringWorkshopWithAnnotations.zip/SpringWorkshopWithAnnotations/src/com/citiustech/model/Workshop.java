package com.citiustech.model;

public interface Workshop {

	public void conductWorkshop();
}
