package com.citiustech.model;

import java.util.List;

public class JavaTrainer implements Trainer {
	
	private String name;
	private List<String> subjects;
	
	public JavaTrainer() {
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless ctor of JavaTrainer");
	}

	public JavaTrainer(String name, List<String> subjects) {
		this.name = name;
		this.subjects = subjects;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getSubjects() {
		return subjects;
	}

	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}

	@Override
	public void train() {
		// TODO Auto-generated method stub
		System.out.println("JavaTrainer::train()");
		System.out.printf("%s is training on %s%n", name, subjects);
	}

	@Override
	public String toString() {
		return "JavaTrainer [name=" + name + ", subjects=" + subjects + "]";
	}
}
