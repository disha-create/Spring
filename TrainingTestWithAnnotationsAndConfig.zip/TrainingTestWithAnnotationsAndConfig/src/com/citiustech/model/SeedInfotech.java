package com.citiustech.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class SeedInfotech implements TrainingCompany {
	
	@Autowired
	//@Qualifier("dotnetTrainer")
	private Trainer trainer;
	
	public SeedInfotech() {
		// TODO Auto-generated constructor stub
		System.out.println("Parameterless ctor of SeedInfotech");
	}
	
	public SeedInfotech(Trainer trainer) {
		super();
		this.trainer = trainer;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	@Override
	public void conductTraining() {
		// TODO Auto-generated method stub
		System.out.println("SeedInfotech::conductTraining()");
		trainer.train();
	}

}
